document.addEventListener('DOMContentLoaded', function () {
  // ---------- Search drawer toggle ----------
  var searchToggle = document.querySelector('[data-search-toggle]');
  var searchDrawer = document.querySelector('[data-search-drawer]');
  if (searchToggle && searchDrawer) {
    searchToggle.addEventListener('click', function () {
      searchDrawer.hidden = !searchDrawer.hidden;
      if (!searchDrawer.hidden) {
        var input = searchDrawer.querySelector('input[type="search"]');
        if (input) input.focus();
      }
    });
  }

  // ---------- Mobile nav toggle ----------
  var menuToggle = document.querySelector('[data-mobile-menu-toggle]');
  var nav = document.querySelector('.header__nav');
  if (menuToggle && nav) {
    menuToggle.addEventListener('click', function () {
      nav.classList.toggle('header__nav--open');
    });
  }

  // ---------- Quantity input buttons (product page + cart + quick view) ----------
  function bindQuantityInputs(scope) {
    (scope || document).querySelectorAll('.quantity-input').forEach(function (wrap) {
      if (wrap.dataset.bound) return;
      wrap.dataset.bound = 'true';
      var input = wrap.querySelector('[data-quantity-field]');
      var decrease = wrap.querySelector('[data-quantity-decrease]');
      var increase = wrap.querySelector('[data-quantity-increase]');
      if (!input) return;
      decrease.addEventListener('click', function () {
        var val = Math.max(1, parseInt(input.value || '1', 10) - 1);
        input.value = val;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
      increase.addEventListener('click', function () {
        var val = parseInt(input.value || '1', 10) + 1;
        input.value = val;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    });
  }
  bindQuantityInputs(document);
  window.bindQuantityInputs = bindQuantityInputs;

  // ---------- Product tabs ----------
  function bindProductTabs(scope) {
    (scope || document).querySelectorAll('[data-product-tabs]').forEach(function (tabs) {
      if (tabs.dataset.bound) return;
      tabs.dataset.bound = 'true';
      tabs.querySelectorAll('[data-tab-button]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var target = btn.getAttribute('data-tab-button');
          tabs.querySelectorAll('[data-tab-button]').forEach(function (b) {
            b.classList.toggle('product__tab-button--active', b === btn);
          });
          tabs.querySelectorAll('[data-tab-panel]').forEach(function (panel) {
            panel.hidden = panel.getAttribute('data-tab-panel') !== target;
          });
        });
      });
    });
  }
  bindProductTabs(document);

  // ---------- Image zoom (follows cursor on hover, desktop only) ----------
  function bindImageZoom(scope) {
    (scope || document).querySelectorAll('[data-zoom-container]').forEach(function (container) {
      if (container.dataset.zoomBound) return;
      container.dataset.zoomBound = 'true';
      var img = container.querySelector('[data-zoom-image]');
      if (!img) return;
      container.addEventListener('mousemove', function (e) {
        var rect = container.getBoundingClientRect();
        var x = ((e.clientX - rect.left) / rect.width) * 100;
        var y = ((e.clientY - rect.top) / rect.height) * 100;
        img.style.transformOrigin = x + '% ' + y + '%';
      });
    });
  }
  bindImageZoom(document);

  // ---------- Product page: thumbnail gallery ----------
  function bindThumbnails(scope) {
    (scope || document).querySelectorAll('[data-thumbnail]').forEach(function (thumb) {
      if (thumb.dataset.bound) return;
      thumb.dataset.bound = 'true';
      thumb.addEventListener('click', function () {
        var mainImage = (scope || document).querySelector('#ProductMainImage');
        if (mainImage) mainImage.src = thumb.getAttribute('data-full-src');
        (scope || document).querySelectorAll('[data-thumbnail]').forEach(function (t) {
          t.classList.remove('product__thumbnail--active');
        });
        thumb.classList.add('product__thumbnail--active');
      });
    });
  }
  bindThumbnails(document);

  // ---------- Product page / Quick view: variant selection (price/id/availability update) ----------
  function setupProductForm(scope, variants) {
    var optionSelectors = scope.querySelectorAll('[data-option-selector]');
    if (!optionSelectors.length || !variants) return;
    var form = scope.querySelector('[id^="ProductForm"]');
    var variantIdInput = form ? form.querySelector('[data-variant-id-input]') : null;
    var addToCartBtn = form ? form.querySelector('[data-add-to-cart]') : null;
    var addToCartText = form ? form.querySelector('[data-add-to-cart-text]') : null;
    var priceWrapper = scope.querySelector('[data-price-wrapper]');

    function getSelectedOptions() {
      var values = [];
      optionSelectors.forEach(function (sel) {
        values[parseInt(sel.getAttribute('data-option-index'), 10) - 1] = sel.value;
      });
      return values;
    }

    function findMatchingVariant() {
      var selected = getSelectedOptions();
      return variants.find(function (variant) {
        return selected.every(function (val, i) {
          return variant['option' + (i + 1)] === val;
        });
      });
    }

    function money(cents) { return '$' + (cents / 100).toFixed(2); }

    function updateForVariant(variant) {
      if (!variant) return;
      if (variantIdInput) variantIdInput.value = variant.id;
      if (addToCartBtn) addToCartBtn.disabled = !variant.available;
      if (addToCartText) addToCartText.textContent = variant.available ? 'Add to Cart' : 'Sold Out';
      if (priceWrapper) {
        if (variant.compare_at_price && variant.compare_at_price > variant.price) {
          priceWrapper.innerHTML = '<div class="price"><span class="price__sale">' + money(variant.price) +
            '</span><span class="price__compare">' + money(variant.compare_at_price) + '</span></div>';
        } else {
          priceWrapper.innerHTML = '<div class="price"><span class="price__regular">' + money(variant.price) + '</span></div>';
        }
      }
      if (variant.featured_image) {
        var mainImage = scope.querySelector('#ProductMainImage');
        if (mainImage) mainImage.src = variant.featured_image.src;
      }
    }

    optionSelectors.forEach(function (sel) {
      sel.addEventListener('change', function () {
        updateForVariant(findMatchingVariant());
      });
    });

    // Color swatch buttons drive the (visually hidden) select they sit next to
    scope.querySelectorAll('.swatch-button').forEach(function (btn) {
      if (btn.dataset.bound) return;
      btn.dataset.bound = 'true';
      btn.addEventListener('click', function () {
        var group = btn.closest('.swatch-group');
        group.querySelectorAll('.swatch-button').forEach(function (b) {
          b.classList.remove('swatch-button--active');
        });
        btn.classList.add('swatch-button--active');
        var select = btn.closest('.product__option').querySelector('[data-option-selector]');
        if (select) {
          select.value = btn.getAttribute('data-swatch-value');
          select.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
    });
  }
  if (window.productVariants) {
    setupProductForm(document, window.productVariants);
  }
  window.setupProductForm = setupProductForm;

  // ---------- Cart page: quantity update + remove (AJAX) ----------
  var cartForm = document.getElementById('CartForm');
  if (cartForm) {
    cartForm.querySelectorAll('[data-quantity-field]').forEach(function (input) {
      input.addEventListener('change', function () {
        var line = input.closest('[data-cart-item]').getAttribute('data-line');
        fetch('/cart/change.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ line: line, quantity: input.value })
        }).then(function () { window.location.reload(); });
      });
    });

    cartForm.querySelectorAll('[data-cart-remove]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var line = btn.getAttribute('data-line');
        fetch('/cart/change.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ line: line, quantity: 0 })
        }).then(function () { window.location.reload(); });
      });
    });
  }

  // ---------- Product recommendations (native Shopify recommendations API) ----------
  document.querySelectorAll('[data-product-recommendations]').forEach(function (el) {
    var url = el.getAttribute('data-url');
    if (!url) return;
    fetch(url)
      .then(function (res) { return res.text(); })
      .then(function (html) {
        var parser = new DOMParser();
        var doc = parser.parseFromString(html, 'text/html');
        var content = doc.querySelector('[data-product-recommendations]');
        if (content && content.innerHTML.trim().length) {
          el.innerHTML = content.innerHTML;
        }
      })
      .catch(function () {});
  });

  // ---------- Recently viewed (localStorage-based) ----------
  var RECENTLY_VIEWED_KEY = 'xitorque_recently_viewed';
  var MAX_RECENTLY_VIEWED = 8;

  function getRecentlyViewed() {
    try {
      return JSON.parse(localStorage.getItem(RECENTLY_VIEWED_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function saveRecentlyViewed(list) {
    try {
      localStorage.setItem(RECENTLY_VIEWED_KEY, JSON.stringify(list.slice(0, MAX_RECENTLY_VIEWED)));
    } catch (e) {}
  }

  // Record current product if on a product page
  var productEl = document.querySelector('[data-section-type="main-product"]');
  if (productEl && productEl.getAttribute('data-product-url')) {
    var current = {
      title: productEl.getAttribute('data-product-title'),
      url: productEl.getAttribute('data-product-url'),
      image: productEl.getAttribute('data-product-image'),
      price: productEl.getAttribute('data-product-price')
    };
    var list = getRecentlyViewed().filter(function (p) { return p.url !== current.url; });
    list.unshift(current);
    saveRecentlyViewed(list);
  }

  // Render recently viewed grid (excluding current page's product)
  var recentlyViewedSection = document.querySelector('[data-recently-viewed]');
  if (recentlyViewedSection) {
    var grid = recentlyViewedSection.querySelector('[data-recently-viewed-grid]');
    var currentUrl = window.location.pathname;
    var items = getRecentlyViewed().filter(function (p) { return p.url !== currentUrl; });

    if (items.length > 0 && grid) {
      grid.innerHTML = items.slice(0, 4).map(function (p) {
        return '' +
          '<div class="product-card">' +
            '<a href="' + p.url + '" class="product-card__link">' +
              '<div class="product-card__image-wrap">' +
                '<img src="' + p.image + '" alt="' + p.title + '" loading="lazy" class="product-card__image">' +
              '</div>' +
              '<div class="product-card__info">' +
                '<h3 class="product-card__title">' + p.title + '</h3>' +
                '<div class="product-card__price"><span>' + p.price + '</span></div>' +
              '</div>' +
            '</a>' +
          '</div>';
      }).join('');
      recentlyViewedSection.hidden = false;
    }
  }

  // ---------- Quick View modal ----------
  var quickViewModal = document.querySelector('[data-quick-view-modal]');
  if (quickViewModal) {
    var qvContent = quickViewModal.querySelector('[data-quick-view-content]');
    var qvClose = quickViewModal.querySelector('[data-quick-view-close]');

    function openQuickView() {
      quickViewModal.hidden = false;
      document.body.style.overflow = 'hidden';
    }
    function closeQuickView() {
      quickViewModal.hidden = true;
      document.body.style.overflow = '';
      qvContent.innerHTML = '';
    }
    qvClose.addEventListener('click', closeQuickView);
    quickViewModal.addEventListener('click', function (e) {
      if (e.target === quickViewModal) closeQuickView();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !quickViewModal.hidden) closeQuickView();
    });

    document.querySelectorAll('[data-quick-view-button]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var url = btn.getAttribute('data-product-url');
        if (!url) return;
        qvContent.innerHTML = '<p class="quick-view__loading">Loading...</p>';
        openQuickView();

        fetch(url + '?section_id=main-product')
          .then(function (res) { return res.text(); })
          .then(function (html) {
            var variantMatch = html.match(/window\.productVariants\s*=\s*(\[[\s\S]*?\]);/);
            var variants = null;
            if (variantMatch) {
              try { variants = JSON.parse(variantMatch[1]); } catch (e) {}
            }
            var parser = new DOMParser();
            var doc = parser.parseFromString(html, 'text/html');
            var main = doc.querySelector('[data-section-type="main-product"]');
            if (main) {
              // Trim thumbnails/description for a more compact quick-view experience
              var thumbs = main.querySelector('.product__thumbnails');
              if (thumbs) thumbs.remove();
              qvContent.innerHTML = '';
              qvContent.appendChild(main);
              bindQuantityInputs(qvContent);
              if (variants) setupProductForm(qvContent, variants);
              bindProductTabs(qvContent);
              bindImageZoom(qvContent);

              var viewFull = document.createElement('a');
              viewFull.href = url;
              viewFull.className = 'quick-view__full-link';
              viewFull.textContent = 'View full details \u2192';
              qvContent.appendChild(viewFull);
            } else {
              qvContent.innerHTML = '<p>Unable to load product.</p>';
            }
          })
          .catch(function () {
            qvContent.innerHTML = '<p>Something went wrong. Please try again.</p>';
          });
      });
    });
  }
});

// ============================================================
// PHASE 6: Cart Drawer, AJAX Add-to-Cart, Sticky Cart, Quick Buy
// ============================================================
document.addEventListener('DOMContentLoaded', function () {

  function updateCartCount() {
    fetch('/cart.js')
      .then(function (res) { return res.json(); })
      .then(function (cart) {
        document.querySelectorAll('[data-cart-count]').forEach(function (el) {
          el.textContent = cart.item_count;
        });
      })
      .catch(function () {});
  }

  var cartDrawer = document.querySelector('[data-cart-drawer]');

  function openCartDrawer() {
    if (!cartDrawer) return;
    cartDrawer.hidden = false;
    document.body.style.overflow = 'hidden';
  }
  function closeCartDrawer() {
    if (!cartDrawer) return;
    cartDrawer.hidden = true;
    document.body.style.overflow = '';
  }
  window.openCartDrawer = openCartDrawer;

  function refreshCartDrawer(callback) {
    if (!cartDrawer) { updateCartCount(); if (callback) callback(); return; }
    fetch('/?sections=cart-drawer')
      .then(function (res) { return res.json(); })
      .then(function (data) {
        var html = data['cart-drawer'];
        if (html) {
          var parser = new DOMParser();
          var doc = parser.parseFromString(html, 'text/html');
          var fresh = doc.querySelector('[data-cart-drawer]');
          if (fresh) {
            cartDrawer.innerHTML = fresh.innerHTML;
            window.bindQuantityInputs(cartDrawer);
          }
        }
        updateCartCount();
        if (callback) callback();
      })
      .catch(function () {
        updateCartCount();
        if (callback) callback();
      });
  }

  // Open drawer from header cart icon
  document.querySelectorAll('[data-cart-drawer-toggle]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      openCartDrawer();
    });
  });

  if (cartDrawer) {
    // Close + remove-item + overlay click (event delegation, survives content refresh)
    cartDrawer.addEventListener('click', function (e) {
      if (e.target.closest('[data-cart-drawer-close]') || e.target.matches('[data-cart-drawer-overlay]')) {
        closeCartDrawer();
        return;
      }
      var removeBtn = e.target.closest('[data-cart-remove]');
      if (removeBtn) {
        var line = removeBtn.getAttribute('data-line');
        fetch('/cart/change.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ line: line, quantity: 0 })
        }).then(function () { refreshCartDrawer(); });
      }
    });

    // Quantity change inside drawer (event delegation)
    cartDrawer.addEventListener('change', function (e) {
      if (e.target.matches('[data-quantity-field]')) {
        var itemEl = e.target.closest('[data-cart-item]');
        if (!itemEl) return;
        var line = itemEl.getAttribute('data-line');
        fetch('/cart/change.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ line: line, quantity: e.target.value })
        }).then(function () { refreshCartDrawer(); });
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !cartDrawer.hidden) closeCartDrawer();
    });
  }

  // ---------- AJAX Add to Cart (works for main product form AND quick-view form) ----------
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form.querySelector || !form.querySelector('[data-add-to-cart]')) return;
    e.preventDefault();

    var btn = form.querySelector('[data-add-to-cart]');
    var btnText = form.querySelector('[data-add-to-cart-text]');
    var originalText = btnText ? btnText.textContent : '';
    if (btn) btn.disabled = true;
    if (btnText) btnText.textContent = 'Adding...';

    var formData = new FormData(form);

    fetch('/cart/add.js', {
      method: 'POST',
      headers: { 'Accept': 'application/json' },
      body: formData
    })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.status) { throw data; }
        var quickViewModal = document.querySelector('[data-quick-view-modal]');
        if (quickViewModal && !quickViewModal.hidden) {
          quickViewModal.hidden = true;
          document.body.style.overflow = '';
        }
        refreshCartDrawer(function () { openCartDrawer(); });
      })
      .catch(function () {
        if (btnText) btnText.textContent = 'Error \u2014 try again';
      })
      .finally(function () {
        if (btn) btn.disabled = false;
        setTimeout(function () {
          if (btnText) btnText.textContent = originalText;
        }, 1500);
      });
  });

  // ---------- Sticky cart bar (product page) ----------
  var stickyBar = document.querySelector('[data-sticky-cart-bar]');
  var mainAddToCartBtn = document.querySelector('.product__add-to-cart');
  if (stickyBar && mainAddToCartBtn && 'IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        stickyBar.hidden = entry.isIntersecting;
      });
    }, { threshold: 0 });
    observer.observe(mainAddToCartBtn);

    var stickyBtn = stickyBar.querySelector('[data-sticky-add-to-cart]');
    if (stickyBtn) {
      stickyBtn.addEventListener('click', function () {
        var mainForm = document.getElementById('ProductForm');
        if (mainForm) {
          mainForm.requestSubmit ? mainForm.requestSubmit() : mainForm.dispatchEvent(new Event('submit', { cancelable: true }));
        }
      });
    }
  }

  // ---------- Quick Buy (product cards) ----------
  document.querySelectorAll('[data-quick-buy-button]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var variantId = btn.getAttribute('data-variant-id');
      if (!variantId) return;
      var originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = 'Adding...';

      fetch('/cart/add.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ id: variantId, quantity: 1 })
      })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (data.status) { throw data; }
          refreshCartDrawer(function () { openCartDrawer(); });
        })
        .catch(function () {
          btn.textContent = 'Error';
        })
        .finally(function () {
          btn.disabled = false;
          setTimeout(function () { btn.textContent = originalText; }, 1200);
        });
    });
  });
});

// ============================================================
// PHASE 9: Announcement bar, Cart notes, Filters, Countdown,
// Slideshow, Size chart, Product videos, Stock counter
// ============================================================
document.addEventListener('DOMContentLoaded', function () {

  // ---------- Announcement bar dismiss ----------
  var announcementBar = document.querySelector('[data-announcement-bar]');
  if (announcementBar) {
    if (localStorage.getItem('xitorque_announcement_dismissed') === 'true') {
      announcementBar.hidden = true;
    }
    var closeBtn = announcementBar.querySelector('[data-announcement-close]');
    if (closeBtn) {
      closeBtn.addEventListener('click', function () {
        announcementBar.hidden = true;
        localStorage.setItem('xitorque_announcement_dismissed', 'true');
      });
    }
  }

  // ---------- Cart notes ----------
  document.querySelectorAll('[data-cart-note]').forEach(function (textarea) {
    var timer;
    textarea.addEventListener('input', function () {
      clearTimeout(timer);
      timer = setTimeout(function () {
        fetch('/cart/update.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ note: textarea.value })
        });
      }, 600);
    });
  });

  // ---------- Collection filters (auto-submit on checkbox change) ----------
  var filterForm = document.getElementById('CollectionFilterForm');
  if (filterForm) {
    filterForm.querySelectorAll('[data-filter-checkbox]').forEach(function (checkbox) {
      checkbox.addEventListener('change', function () {
        filterForm.requestSubmit ? filterForm.requestSubmit() : filterForm.submit();
      });
    });
  }

  // ---------- Countdown timer ----------
  document.querySelectorAll('[data-countdown]').forEach(function (el) {
    var endDate = new Date(el.getAttribute('data-end'));
    var daysEl = el.querySelector('[data-countdown-days]');
    var hoursEl = el.querySelector('[data-countdown-hours]');
    var minutesEl = el.querySelector('[data-countdown-minutes]');
    var secondsEl = el.querySelector('[data-countdown-seconds]');

    function pad(n) { return String(n).padStart(2, '0'); }

    function tick() {
      var now = new Date();
      var diff = endDate - now;
      if (diff <= 0) {
        el.querySelector('.countdown-timer__display').innerHTML = '<p>This offer has ended.</p>';
        clearInterval(interval);
        return;
      }
      var days = Math.floor(diff / (1000 * 60 * 60 * 24));
      var hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      var minutes = Math.floor((diff / (1000 * 60)) % 60);
      var seconds = Math.floor((diff / 1000) % 60);
      if (daysEl) daysEl.textContent = pad(days);
      if (hoursEl) hoursEl.textContent = pad(hours);
      if (minutesEl) minutesEl.textContent = pad(minutes);
      if (secondsEl) secondsEl.textContent = pad(seconds);
    }
    tick();
    var interval = setInterval(tick, 1000);
  });

  // ---------- Slideshow ----------
  document.querySelectorAll('[data-slideshow]').forEach(function (slideshow) {
    var slides = slideshow.querySelectorAll('[data-slide]');
    var dots = slideshow.querySelectorAll('[data-slide-dot]');
    if (slides.length < 2) return;
    var current = 0;
    var autoplay = slideshow.getAttribute('data-autoplay') === 'true';
    var interval = parseInt(slideshow.getAttribute('data-interval'), 10) || 5000;
    var timer;

    function goTo(index) {
      slides[current].classList.remove('slideshow__slide--active');
      if (dots[current]) dots[current].classList.remove('slideshow__dot--active');
      current = (index + slides.length) % slides.length;
      slides[current].classList.add('slideshow__slide--active');
      if (dots[current]) dots[current].classList.add('slideshow__dot--active');
    }

    function startAutoplay() {
      if (!autoplay) return;
      timer = setInterval(function () { goTo(current + 1); }, interval);
    }
    function stopAutoplay() { clearInterval(timer); }

    var prevBtn = slideshow.querySelector('[data-slide-prev]');
    var nextBtn = slideshow.querySelector('[data-slide-next]');
    if (prevBtn) prevBtn.addEventListener('click', function () { stopAutoplay(); goTo(current - 1); startAutoplay(); });
    if (nextBtn) nextBtn.addEventListener('click', function () { stopAutoplay(); goTo(current + 1); startAutoplay(); });
    dots.forEach(function (dot, i) {
      dot.addEventListener('click', function () { stopAutoplay(); goTo(i); startAutoplay(); });
    });

    startAutoplay();
  });

  // ---------- Size chart modal ----------
  var sizeChartModal = document.querySelector('[data-size-chart-modal]');
  if (sizeChartModal) {
    document.querySelectorAll('[data-size-chart-open]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        sizeChartModal.hidden = false;
        document.body.style.overflow = 'hidden';
      });
    });
    sizeChartModal.querySelectorAll('[data-size-chart-close]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        sizeChartModal.hidden = true;
        document.body.style.overflow = '';
      });
    });
  }

  // ---------- Product videos in gallery ----------
  document.querySelectorAll('[data-thumbnail][data-video-id]').forEach(function (thumb) {
    thumb.addEventListener('click', function () {
      var videoWrap = document.querySelector('[data-video-wrap]');
      var mainImage = document.querySelector('[data-main-image]');
      if (!videoWrap) return;
      videoWrap.querySelectorAll('[data-video-content]').forEach(function (v) { v.hidden = true; });
      var content = videoWrap.querySelector('[data-video-content="' + thumb.getAttribute('data-video-id') + '"]');
      if (content) {
        content.hidden = false;
        videoWrap.hidden = false;
        if (mainImage) mainImage.hidden = true;
      }
    });
  });
  document.querySelectorAll('[data-thumbnail]:not([data-video-id])').forEach(function (thumb) {
    thumb.addEventListener('click', function () {
      var videoWrap = document.querySelector('[data-video-wrap]');
      var mainImage = document.querySelector('[data-main-image]');
      if (videoWrap) videoWrap.hidden = true;
      if (mainImage) mainImage.hidden = false;
    });
  });
});
